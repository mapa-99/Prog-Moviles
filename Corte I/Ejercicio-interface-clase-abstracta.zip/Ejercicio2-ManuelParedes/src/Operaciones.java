
public interface Operaciones {
	public void conectar();

	public void consultar();

	public void insertar();

	public void eliminar();
}
