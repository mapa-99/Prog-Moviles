
public class Postgres extends BDatos {
	public void conectar() {
		System.out.println("La base de datos está conectada...");

	}

	public void insertar() {

		System.out.println("La base de datos Se actualizó...");

	}

	public void consultar() {
		System.out.println("Info de la base de datos...");

	}

	public void eliminar() {

		System.out.println("Un elemento se ha eliminado...");

	}
}
