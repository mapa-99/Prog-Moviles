

public abstract class BDatos implements Operaciones{

	
}
